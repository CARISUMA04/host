'use strict';
require('dotenv').config();
const express = require('express');
const session = require('express-session');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const API_VERSION = process.env.META_API_VERSION || 'v25.0';
const GRAPH_BASE = 'https://graph.instagram.com';
const DATA_DIR = process.env.PRIVATE_DATA_DIR || path.join(__dirname, '..', 'host-sales-private-data');
const TOKEN_FILE = path.join(DATA_DIR, 'instagram-token.enc.json');
fs.mkdirSync(DATA_DIR, { recursive: true, mode: 0o700 });
app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(express.json({ limit: '64kb' }));
app.use(session({
  name: 'hostsales.sid',
  secret: process.env.SESSION_SECRET || 'DEV_ONLY_CHANGE_THIS_SECRET_BEFORE_DEPLOYMENT',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 60 * 60 * 1000 }
}));
app.use((req, res, next) => {
  if (req.path.startsWith('/api/') || req.path.startsWith('/auth/')) res.set('Cache-Control', 'no-store');
  res.set('X-Content-Type-Options', 'nosniff');
  res.set('Referrer-Policy', 'no-referrer');
  next();
});
app.use(express.static(__dirname, { index: 'index.html', dotfiles: 'ignore', etag: false }));

function configured() {
  return Boolean(process.env.APP_ACCESS_PASSWORD && process.env.META_APP_ID && process.env.META_APP_SECRET && process.env.META_REDIRECT_URI &&
    process.env.SESSION_SECRET && process.env.SESSION_SECRET !== 'DEV_ONLY_CHANGE_THIS_SECRET_BEFORE_DEPLOYMENT' &&
    process.env.TOKEN_ENCRYPTION_KEY && /^[a-fA-F0-9]{64}$/.test(process.env.TOKEN_ENCRYPTION_KEY));
}
function encryptionKey() { return Buffer.from(process.env.TOKEN_ENCRYPTION_KEY, 'hex'); }
function readToken() {
  try {
    const box = JSON.parse(fs.readFileSync(TOKEN_FILE, 'utf8'));
    const decipher = crypto.createDecipheriv('aes-256-gcm', encryptionKey(), Buffer.from(box.iv, 'hex'));
    decipher.setAuthTag(Buffer.from(box.tag, 'hex'));
    const raw = Buffer.concat([decipher.update(Buffer.from(box.data, 'base64')), decipher.final()]).toString('utf8');
    return JSON.parse(raw);
  } catch (e) {
    if (e.code === 'ENOENT') return null;
    console.error('Could not read encrypted token store:', e.message);
    return null;
  }
}
function writeToken(token) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', encryptionKey(), iv);
  const encrypted = Buffer.concat([cipher.update(JSON.stringify(token), 'utf8'), cipher.final()]);
  const box = { v: 1, iv: iv.toString('hex'), tag: cipher.getAuthTag().toString('hex'), data: encrypted.toString('base64') };
  const tmp = TOKEN_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(box), { mode: 0o600 });
  fs.renameSync(tmp, TOKEN_FILE);
}
function clearToken() { try { fs.unlinkSync(TOKEN_FILE); } catch (e) { if (e.code !== 'ENOENT') throw e; } }
function sameOrigin(req) {
  const origin = req.get('origin');
  if (!origin) return true; // native/local clients may omit Origin; session cookie is still SameSite=Lax
  try { return new URL(origin).host === req.get('host'); } catch { return false; }
}
function requireSameOrigin(req, res, next) {
  if (!sameOrigin(req)) return res.status(403).json({ error: 'Origin check failed. Reload the app and retry.' });
  next();
}
async function fetchJson(url, options = {}) {
  const response = await fetch(url, { ...options, signal: AbortSignal.timeout(20000) });
  const json = await response.json().catch(() => ({}));
  if (!response.ok || json.error) {
    const message = json.error?.message || json.error_message || `Instagram API returned HTTP ${response.status}`;
    throw new Error(message);
  }
  return json;
}
async function apiGet(pathname, token, params = {}) {
  const url = new URL(`${GRAPH_BASE}/${API_VERSION}/${pathname.replace(/^\//, '')}`);
  for (const [key, value] of Object.entries(params)) if (value !== undefined && value !== null) url.searchParams.set(key, String(value));
  // Keep access tokens out of application logs; Instagram Graph API accepts bearer auth.
  return fetchJson(url, { headers: { Authorization: `Bearer ${token}` } });
}
function publicStatus(token) {
  return {
    configured: configured(), connected: Boolean(token?.access_token), username: token?.username || null,
    accountType: token?.account_type || null, lastSync: token?.last_sync || null,
    expiresAt: token?.expires_at ? new Date(token.expires_at).toISOString() : null,
    scopes: token?.scopes || [], note: token?.note || null
  };
}

function safeEqual(a, b) {
  const aa = Buffer.from(String(a || ''));
  const bb = Buffer.from(String(b || ''));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
app.get('/api/access/status', (req, res) => res.json({ needsPassword: true, authorized: Boolean(req.session.appAuthorized) }));
app.post('/api/access/login', requireSameOrigin, (req, res) => {
  if (!process.env.APP_ACCESS_PASSWORD) return res.status(503).json({ error: 'APP_ACCESS_PASSWORDをサーバーに設定してください。' });
  if (!safeEqual(req.body?.password, process.env.APP_ACCESS_PASSWORD)) return res.status(401).json({ error: '管理用パスワードが違います。' });
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: 'ログインセッションを更新できませんでした。' });
    req.session.appAuthorized = true;
    req.session.save(saveErr => saveErr ? res.status(500).json({ error: 'ログイン状態を保存できませんでした。' }) : res.json({ ok: true }));
  });
});
function requireAppAuth(req, res, next) {
  if (!req.session.appAuthorized) return res.status(401).json({ error: 'このアプリの管理用パスワードを入力してください。', appAuthRequired: true });
  next();
}
app.get('/api/instagram/status', requireAppAuth, (req, res) => res.json(publicStatus(readToken())));
app.use('/api/instagram', requireAppAuth);
app.use('/auth/instagram', requireAppAuth);
app.get('/auth/instagram', (req, res) => {
  if (!configured()) return res.status(503).send('Instagram連携の設定が未完了です。.envのMETA_APP_ID、META_APP_SECRET、META_REDIRECT_URI、SESSION_SECRET、TOKEN_ENCRYPTION_KEYを確認してください。');
  const state = crypto.randomBytes(32).toString('hex');
  req.session.igOAuthState = state;
  const url = new URL('https://www.instagram.com/oauth/authorize');
  url.searchParams.set('client_id', process.env.META_APP_ID);
  url.searchParams.set('redirect_uri', process.env.META_REDIRECT_URI);
  url.searchParams.set('response_type', 'code');
  url.searchParams.set('scope', (process.env.META_SCOPES || 'instagram_business_basic,instagram_business_manage_insights,instagram_business_manage_messages').replace(/\s/g, ''));
  url.searchParams.set('state', state);
  url.searchParams.set('enable_fb_login', '0');
  url.searchParams.set('force_reauth', 'true');
  req.session.save(err => {
    if (err) return res.status(500).send('ログインセッションを保存できませんでした。もう一度お試しください。');
    res.redirect(url.toString());
  });
});
app.get('/auth/instagram/callback', async (req, res) => {
  try {
    if (!configured()) throw new Error('サーバー設定が未完了です。');
    if (req.query.error) throw new Error(String(req.query.error_description || req.query.error));
    if (!req.query.state || !req.session.igOAuthState || req.query.state !== req.session.igOAuthState) throw new Error('認証状態の確認に失敗しました。Instagram連携をやり直してください。');
    delete req.session.igOAuthState;
    const code = String(req.query.code || '').replace(/#_$/, '');
    if (!code) throw new Error('Instagramから認証コードが返されませんでした。');
    const body = new URLSearchParams({ client_id: process.env.META_APP_ID, client_secret: process.env.META_APP_SECRET, grant_type: 'authorization_code', redirect_uri: process.env.META_REDIRECT_URI, code });
    const short = await fetchJson('https://api.instagram.com/oauth/access_token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body });
    if (!short.access_token) throw new Error('アクセストークンを取得できませんでした。');
    let accessToken = short.access_token;
    let expiresIn = Number(short.expires_in || 3600);
    try {
      const longUrl = new URL(`${GRAPH_BASE}/access_token`);
      longUrl.searchParams.set('grant_type', 'ig_exchange_token');
      longUrl.searchParams.set('client_secret', process.env.META_APP_SECRET);
      longUrl.searchParams.set('access_token', accessToken);
      const long = await fetchJson(longUrl);
      if (long.access_token) { accessToken = long.access_token; expiresIn = Number(long.expires_in || 5184000); }
    } catch (e) { console.warn('Long-lived token exchange failed; using short-lived token:', e.message); }
    const me = await apiGet('me', accessToken, { fields: 'user_id,username,account_type,media_count' });
    const grantedScopes = Array.isArray(short.permissions) ? short.permissions : (Array.isArray(req.query.granted_scopes) ? req.query.granted_scopes : []);
    writeToken({ access_token: accessToken, expires_at: Date.now() + expiresIn * 1000, user_id: me.user_id || me.id, username: me.username, account_type: me.account_type, media_count: me.media_count, scopes: grantedScopes, connected_at: new Date().toISOString(), last_sync: null, note: null });
    res.redirect('/?instagram_connected=1');
  } catch (e) {
    console.error('Instagram OAuth callback failed:', e.message);
    res.redirect('/?instagram_error=' + encodeURIComponent(e.message).slice(0, 350));
  }
});
app.post('/api/instagram/disconnect', requireSameOrigin, (req, res) => {
  try { clearToken(); res.json({ ok: true, note: 'このアプリに保存したトークンを削除しました。Meta側のアプリ権限の解除は、Instagram/Metaの設定画面でも確認してください。' }); }
  catch (e) { res.status(500).json({ error: '接続情報を削除できませんでした。' }); }
});
app.post('/api/instagram/sync', requireSameOrigin, async (req, res) => {
  const token = readToken();
  if (!token?.access_token) return res.status(401).json({ error: 'Instagramが未接続です。先に公式ログインを完了してください。' });
  if (token.expires_at && token.expires_at < Date.now()) return res.status(401).json({ error: 'アクセストークンの有効期限が切れています。再接続してください。' });
  const warnings = [];
  try {
    const profile = await apiGet('me', token.access_token, { fields: 'user_id,username,account_type,media_count' });
    const userId = profile.user_id || profile.id;
    let media = [];
    try {
      const result = await apiGet(`${userId}/media`, token.access_token, { fields: 'id,caption,media_type,permalink,timestamp,like_count,comments_count', limit: 50 });
      media = result.data || [];
    } catch (e) { warnings.push(`投稿一覧：${e.message}`); }
    const insights = {};
    for (const metric of ['reach', 'accounts_engaged', 'total_interactions', 'profile_views', 'views']) {
      try {
        const result = await apiGet(`${userId}/insights`, token.access_token, { metric, period: 'day' });
        insights[metric] = result.data || [];
      } catch (e) { insights[metric] = null; warnings.push(`インサイト(${metric})：${e.message}`); }
    }
    let messaging = { available: false, conversationCount: null, note: 'DM取得はメッセージ権限・審査・アカウント条件によって異なります。' };
    try {
      const result = await apiGet(`${userId}/conversations`, token.access_token, { platform: 'instagram', limit: 50 });
      messaging = { available: true, conversationCount: (result.data || []).length, note: '取得できた会話スレッド数です。全DMや本文の取得を保証するものではありません。' };
    } catch (e) {
      messaging.error = e.message;
      warnings.push('DM会話一覧は取得できませんでした。メッセージ権限、アプリ審査、API仕様を確認してください。');
    }
    const totals = media.reduce((sum, item) => ({ likes: sum.likes + Number(item.like_count || 0), comments: sum.comments + Number(item.comments_count || 0) }), { likes: 0, comments: 0 });
    token.username = profile.username || token.username;
    token.account_type = profile.account_type || token.account_type;
    token.media_count = profile.media_count;
    token.last_sync = new Date().toISOString();
    token.note = warnings.length ? warnings.join('\n') : '同期処理が完了しました。取得範囲は権限とAPI仕様に依存します。';
    writeToken(token);
    res.json({ syncedAt: token.last_sync, profile, media, totals, insights, messaging, warnings, analysis: { postsReturned: media.length, likesInReturnedPosts: totals.likes, commentsInReturnedPosts: totals.comments, note: 'いいね・コメント合計はAPIから返された投稿分のみ。投稿全期間や売上との因果関係を示すものではありません。' } });
  } catch (e) {
    const msg = e.message || 'Instagram APIとの通信に失敗しました。';
    res.status(502).json({ error: msg });
  }
});
app.get('/health', (req, res) => res.json({ ok: true, configured: configured() }));
app.listen(PORT, () => console.log(`HOST SALES ANALYZER server listening on port ${PORT}`));

HOST SALES ANALYZER — Instagram公式OAuth連携版（更新版）
======================================================

このパッケージには、顧客管理・ファネル分析画面、顧客ごとのDM送信数・返信数の手動記録、合計件数・返信数÷送信数の分析、接点別件数比較、Instagram公式OAuthログイン画面、Node.jsバックエンド、暗号化トークン保存、接続状態確認、接続解除、手動同期・分析が含まれます。

重要：ダウンロードしただけではInstagram連携は完成しません。Meta for Developersでアプリを作成・設定し、このNode.jsサーバーを起動して公開する必要があります。GitHub Pages単体ではApp Secretやトークンを安全に保管できません。

必要条件
--------
- Node.js 18以上
- HTTPSで公開されたサーバー（本番環境）
- Meta for Developersで作成したアプリとInstagram Login / Business Login設定
- Instagramプロアカウント（ビジネスまたはクリエイター）
- 使用するAPI権限の設定。機能によってMeta App Review / Advanced Accessが必要
- サーバー上の永続ディスク（トークンファイル保存用）

セットアップ
------------
1. このフォルダをサーバーに配置します。
2. .env.exampleを.envにコピーします。
3. APP_ACCESS_PASSWORDに、Instagramパスワードとは別の長くランダムな「アプリ管理用パスワード」を設定します。公開URLで第三者に操作されないために必要です。
4. Meta for DevelopersでInstagram Login / Business Loginを有効化し、App IDとApp Secretを取得します。
5. META_APP_IDとMETA_APP_SECRETを.envに設定します。
6. META_REDIRECT_URIを、公開サーバーの https://あなたのドメイン/auth/instagram/callback に設定します。
7. MetaのBusiness Login設定に、完全一致するOAuth Redirect URIを登録します。
8. SESSION_SECRETに長いランダム文字列を設定します。
9. TOKEN_ENCRYPTION_KEYには64桁の16進数を設定します。生成例：
   node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
10. META_SCOPESはMetaダッシュボードで有効化した権限だけを指定します。既定値は instagram_business_basic,instagram_business_manage_insights,instagram_business_manage_messages です。
11. ターミナルで npm install、続けて npm start を実行します。
12. サーバーのURLを開き、Instagram連携タブでアプリ管理用パスワードを入力します。
13. 「Instagramを接続」を押し、Instagram公式の認証画面で許可します。
14. 接続状態を確認し、「データを同期・分析」を押します。

重要なセキュリティ情報
----------------------
- InstagramのID・パスワードをこのアプリが受け取るフォームはありません。ログインはInstagram公式のOAuth画面に移動します。
- アクセストークンは公開ディレクトリ外のhost-sales-private-data/instagram-token.enc.jsonにAES-256-GCMで暗号化して保存します。暗号鍵は.env内のTOKEN_ENCRYPTION_KEYに置き、絶対に公開リポジトリへアップロードしないでください。
- .env、host-sales-private-data/、顧客CSV、Meta App SecretはGitHubなどにアップロードしないでください。
- この実装は個人・単一オペレーター向けです。複数ユーザーに公開するサービスとして使う前に、永続セッションストア、アカウントごとの認証・トークン分離、監査ログ、レート制限、運用監視、データ削除手順などを追加してください。
- Expressの既定セッションストアは開発用です。本番運用ではRedisなどの永続セッションストアに置き換えてください。
- ホスティング環境のディスクが一時的な場合、再デプロイや再起動でトークンが失われる可能性があります。

実装されている機能
------------------
- アプリ管理用パスワードによる操作保護（Instagramのパスワードとは別）
- Instagram公式OAuthの認証開始、state照合、認証コード交換
- 長期トークンへの交換を試行
- トークンのサーバー側暗号化保存
- 接続状態表示、最終同期日時・トークン期限表示、ローカル接続情報の削除
- プロフィールと直近最大50件の投稿を取得
- アカウントインサイトの複数指標を個別に試行し、取得できない指標は警告表示
- DM会話一覧の取得を試行し、失敗した場合は理由を表示
- 取得投稿のいいね数・コメント数を集計
- 顧客ごとのDM送信数・返信数を手動記録し、合計件数・参考比率・接点別の件数を集計（DM件数の自動取得ではありません）

APIの制限・未検証事項
---------------------
- このパッケージを作成した環境では、実際のMetaアプリID・Secretがないため、本物のInstagramアカウントによるOAuthログイン、トークン交換、API取得をエンドツーエンドでは検証していません。
- JavaScriptの構文チェックとサーバーの構文チェックは別途行ってください（手順は下記）。実際のAPI応答は、Meta側の設定・APIバージョン・権限・審査・アカウント条件によって変わります。
- DM会話一覧は取得を試行しますが、DM本文の全件取得やAIによる会話分類はこの版では実装していません。メッセージ機能には専用権限、相手側のメッセージ条件、Metaの審査などが関係します。
- Webhookによるリアルタイム同期、自動返信、自動DM送信は実装していません。
- 投稿のいいね・コメント合計は、APIから今回返された投稿分のみです。全期間の合計や来店・売上との因果関係を示すものではありません。
- インサイト指標名や取得可能な期間はMetaの仕様に依存します。APIエラーが出た指標は画面の警告を確認してください。
- 接続解除ボタンは、このアプリ内の保存トークンを削除します。Meta側の権限解除はInstagram/Metaの設定画面でも確認してください。

公式資料
--------
Instagram API with Instagram Login:
https://developers.facebook.com/docs/instagram-platform/instagram-api-with-instagram-login/
Meta公式Postmanドキュメント：
https://www.postman.com/meta/workspace/instagram/documentation/23987686-9386f468-7714-490f-9bfc-9442db5c8f00
